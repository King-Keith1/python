from django.contrib import admin

from .models import Topic, Entry
admin.site.register(Topic)


# Register your models here.

admin.site.register(Entry)
